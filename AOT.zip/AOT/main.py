﻿from models import (
    SessionLocal,
    Character,
    Species,
    TitanType,
    Organization,
    CharacterTitan,
    CharacterOrganization,
    EpisodeAppearance,   # 👈 add this
)


# ---------- Helper pickers ----------

def choose_species(session):
    print("\nChoose species:")
    options = {
        1: "Human",
        2: "Eldian",
        3: "Marleyan",
        4: "Ackerman",
    }
    for num, name in options.items():
        print(f"{num}. {name}")

    while True:
        try:
            choice = int(input("Species number: "))
            if choice in options:
                species_name = options[choice]
                # get or create species
                species = session.query(Species).filter_by(name=species_name).first()
                if not species:
                    species = Species(name=species_name, description=None)
                    session.add(species)
                    session.commit()
                return species
            else:
                print("Invalid choice. Try again.")
        except ValueError:
            print("Please enter a number.")


def choose_titan_type(session):
    print("\nAssign titan form:")
    options = {
        1: "Attack Titan",
        2: "Colossal Titan",
        3: "Armored Titan",
        4: "Female Titan",
        5: "Beast Titan",
        6: "Jaw Titan",
        7: "Cart Titan",
        8: "Founding Titan",
    }
    for num, name in options.items():
        print(f"{num}. {name}")

    while True:
        try:
            choice = int(input("Titan number (0 to cancel): "))
            if choice == 0:
                return None
            if choice in options:
                titan_name = options[choice]
                titan = session.query(TitanType).filter_by(name=titan_name).first()
                if not titan:
                    titan = TitanType(name=titan_name, description=f"{titan_name} form.")
                    session.add(titan)
                    session.commit()
                return titan
            else:
                print("Invalid choice. Try again.")
        except ValueError:
            print("Please enter a number.")


def choose_organization(session):
    print("\nChoose organization:")
    options = {
        1: "Scout Regiment",
        2: "Garrison Regiment",
        3: "Military Police Brigade",
        4: "Marley Warrior Unit",
    }
    for num, name in options.items():
        print(f"{num}. {name}")

    while True:
        try:
            choice = int(input("Organization number (0 to cancel): "))
            if choice == 0:
                return None
            if choice in options:
                org_name = options[choice]
                org = session.query(Organization).filter_by(name=org_name).first()
                if not org:
                    org = Organization(name=org_name, type="military", description=None)
                    session.add(org)
                    session.commit()
                return org
            else:
                print("Invalid choice. Try again.")
        except ValueError:
            print("Please enter a number.")


# ---------- CRUD functions ----------

def list_characters(session):
    print("\nCharacters:")
    chars = session.query(Character).order_by(Character.character_id).all()
    for c in chars:
        print(f"{c.character_id}: {c.name} (status: {c.status})")
    if not chars:
        print("No characters found.")


def create_character(session):
    print("\n=== Create Character ===")
    name = input("Name: ").strip()
    description = input("Description (optional): ").strip() or None

    species = choose_species(session)
    status = "alive"

    new_char = Character(
        name=name,
        description=description,
        status=status,
        species_id=species.species_id if species else None,
    )
    session.add(new_char)
    session.commit()
    print(f"Created character with ID {new_char.character_id}.")

    # Optional: assign titan form
    assign = input("Assign a titan form now? (y/n): ").strip().lower()
    if assign == "y":
        assign_titan_to_character(session, new_char.character_id)

    # Optional: assign organization
    assign_org = input("Add organization membership now? (y/n): ").strip().lower()
    if assign_org == "y":
        assign_organization_to_character(session, new_char.character_id)


def update_character_status(session):
    print("\n=== Update Character Status ===")
    list_characters(session)
    try:
        char_id = int(input("Enter character ID to update: "))
    except ValueError:
        print("Invalid ID.")
        return

    char = session.get(Character, char_id)
    if not char:
        print("Character not found.")
        return

    print(f"Current status: {char.status}")
    new_status = input("New status (alive/dead/unknown): ").strip().lower()
    if new_status not in ("alive", "dead", "unknown"):
        print("Invalid status.")
        return

    char.status = new_status
    session.commit()
    print("Status updated.")


def delete_character(session):
    list_characters(session)
    try:
        char_id = int(input("\nEnter character ID to delete: "))
    except ValueError:
        print("Invalid ID.")
        return

    char = session.get(Character, char_id)
    if not char:
        print("Character not found.")
        return

    confirm = input(f"Are you sure you want to delete {char.name}? (y/n): ").strip().lower()
    if confirm != "y":
        print("Delete cancelled.")
        return

    try:
        # 1) Delete all related organization memberships
        session.query(CharacterOrganization).filter_by(character_id=char_id).delete()

        # 2) Delete all related titan forms
        session.query(CharacterTitan).filter_by(character_id=char_id).delete()

        # 3) Delete all related episode appearances
        session.query(EpisodeAppearance).filter_by(character_id=char_id).delete()

        # 4) Now delete the character itself
        session.delete(char)

        session.commit()
        print(f"Character {char.name} deleted successfully.")
    except Exception as e:
        session.rollback()
        print("Error while deleting character:", e)



def assign_titan_to_character(session, char_id=None):
    print("\n=== Assign Titan Form ===")
    if char_id is None:
        list_characters(session)
        try:
            char_id = int(input("Enter character ID: "))
        except ValueError:
            print("Invalid ID.")
            return

    char = session.get(Character, char_id)
    if not char:
        print("Character not found.")
        return

    titan = choose_titan_type(session)
    if titan is None:
        print("No titan selected.")
        return

    # Check if already has that titan
    existing = (
        session.query(CharacterTitan)
        .filter_by(character_id=char.character_id, titan_type_id=titan.titan_type_id)
        .first()
    )
    if existing:
        print(f"{char.name} already has {titan.name}.")
        return

    link = CharacterTitan(
        character_id=char.character_id,
        titan_type_id=titan.titan_type_id,
        first_appearance_episode_id=None,  # could be set later
    )
    session.add(link)
    session.commit()
    print(f"Assigned {titan.name} to {char.name}.")


def assign_organization_to_character(session, char_id=None):
    print("\n=== Assign Organization ===")
    if char_id is None:
        list_characters(session)
        try:
            char_id = int(input("Enter character ID: "))
        except ValueError:
            print("Invalid ID.")
            return

    char = session.get(Character, char_id)
    if not char:
        print("Character not found.")
        return

    org = choose_organization(session)
    if org is None:
        print("No organization selected.")
        return

    existing = (
        session.query(CharacterOrganization)
        .filter_by(character_id=char.character_id, organization_id=org.organization_id)
        .first()
    )
    if existing:
        print(f"{char.name} is already in {org.name}.")
        return

    role = input("Role (e.g., Member, Captain, Warrior): ").strip() or "Member"

    link = CharacterOrganization(
        character_id=char.character_id,
        organization_id=org.organization_id,
        role=role,
        join_episode_id=None,  # could link to an episode later
    )
    session.add(link)
    session.commit()
    print(f"Assigned {char.name} to {org.name} as {role}.")


# ---------- Main menu ----------

def main():
    session = SessionLocal()
    try:
        while True:
            print("\n==== AOT Character CRUD ====")
            print("1. List characters")
            print("2. Create character (with species)")
            print("3. Update character status")
            print("4. Delete character")
            print("5. Assign titan form to character")
            print("6. Assign organization to character")
            print("0. Exit")

            choice = input("Choose option: ").strip()

            if choice == "1":
                list_characters(session)
            elif choice == "2":
                create_character(session)
            elif choice == "3":
                update_character_status(session)
            elif choice == "4":
                delete_character(session)
            elif choice == "5":
                assign_titan_to_character(session)
            elif choice == "6":
                assign_organization_to_character(session)
            elif choice == "0":
                print("Goodbye!")
                break
            else:
                print("Invalid choice.")
    finally:
        session.close()


if __name__ == "__main__":
    main()
