﻿from flask import Flask, render_template, request, redirect, url_for
from models import SessionLocal, Character, Species, TitanType, Organization, CharacterTitan, CharacterOrganization
import os
from openai import OpenAI
from models import (
    SessionLocal,
    Character,
    Species,
    TitanType,
    Organization,
    CharacterTitan,
    CharacterOrganization,
    EpisodeAppearance,   # ⬅️ add this
)

# if you really want the key hard-coded, keep it here
client = OpenAI(
    api_key="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"
)

from sqlalchemy import text
from models import engine  # already defined in models.py

app = Flask(__name__)

# ---------- LLM helper (NOT a route) ----------

def question_to_sql(question: str) -> str:
    """
    Ask the LLM to convert a simple English question
    into a SELECT query over our AOT schema.
    """
    schema_description = """
    Tables:

    series(series_id, title, start_year, end_year)
    season(season_id, series_id, season_number, title)
    episode(episode_id, season_id, episode_number, title, air_date)
    species(species_id, name)
    character(character_id, name, status, species_id)
    titan_type(titan_type_id, name)
    character_titan(character_id, titan_type_id)
    organization(organization_id, name)
    character_organization(character_id, organization_id)
    episode_appearance(episode_id, character_id, screen_time_minutes)
    """

    system_msg = (
        "You are a MySQL assistant for an Attack on Titan database. "
        "Convert the user's question into a SINGLE, SAFE SQL SELECT statement. "
        "Do NOT modify data. No INSERT/UPDATE/DELETE. "
        "Only use the tables/columns in the schema. Return ONLY the SQL."
    )

    completion = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": system_msg + schema_description},
            {"role": "user", "content": question},
        ],
        temperature=0
    )

    sql = completion.choices[0].message.content.strip()

    # strip ```sql ... ``` if present
    if "```" in sql:
        parts = sql.split("```")
        if len(parts) >= 3:
            sql = parts[1]
        else:
            sql = parts[-1]
        sql = sql.strip()

    # remove leading "sql" token if present
    if sql.lower().startswith("sql"):
        sql = sql[3:].lstrip()

    # fix reserved table name 'character'
    sql = sql.replace("FROM character", "FROM `character`")
    sql = sql.replace("from character", "FROM `character`")
    sql = sql.replace("JOIN character", "JOIN `character`")
    sql = sql.replace("join character", "JOIN `character`")

    # make sure we end with exactly one ;
    return sql.strip().rstrip(";") + ";"



# Utility: new DB session per request
def get_session():
    return SessionLocal()

# ---------- Home ----------

@app.route("/")
def home():
    return redirect(url_for("list_characters"))

# ---------- List characters (READ) ----------

@app.route("/characters")
def list_characters():
    session = get_session()
    chars = (
        session.query(Character)
        .order_by(Character.character_id)
        .all()
    )
    session.close()
    return render_template("characters.html", characters=chars)

# ---------- Create character (CREATE) ----------

@app.route("/characters/new", methods=["GET", "POST"])
def create_character():
    session = get_session()

    species_list = session.query(Species).order_by(Species.name).all()
    titan_types = session.query(TitanType).order_by(TitanType.name).all()
    orgs = session.query(Organization).order_by(Organization.name).all()

    if request.method == "POST":
        name = request.form["name"]
        status = request.form.get("status", "alive")
        species_id = request.form.get("species_id")
        titan_type_id = request.form.get("titan_type_id")
        organization_id = request.form.get("organization_id")

        # create character row
        char = Character(
            name=name,
            status=status,
            species_id=int(species_id) if species_id else None,
            description="Created from web app",
        )
        session.add(char)
        session.commit()      # so char.character_id is set
        session.refresh(char)

        # optional titan form
        if titan_type_id:
            ct = CharacterTitan(
                character_id=char.character_id,
                titan_type_id=int(titan_type_id)
            )
            session.add(ct)

        # optional organization membership
        if organization_id:
            co = CharacterOrganization(
                character_id=char.character_id,
                organization_id=int(organization_id),
                role="Member"
            )
            session.add(co)

        session.commit()
        session.close()
        return redirect(url_for("list_characters"))

    session.close()
    return render_template(
        "character_form.html",
        mode="create",
        species_list=species_list,
        titan_types=titan_types,
        orgs=orgs,
        character=None
    )

# ---------- Update character status (UPDATE) ----------

@app.route("/characters/<int:char_id>/edit", methods=["GET", "POST"])
def edit_character(char_id):
    session = get_session()
    char = session.get(Character, char_id)

    if not char:
        session.close()
        return "Character not found", 404

    if request.method == "POST":
        new_status = request.form.get("status", "alive")
        char.status = new_status
        session.commit()
        session.close()
        return redirect(url_for("list_characters"))

    session.close()
    return render_template("edit_status.html", character=char)

# ---------- Delete character (DELETE) ----------

@app.route("/characters/<int:char_id>/delete", methods=["POST"])
def delete_character(char_id):
    session = get_session()
    char = session.get(Character, char_id)

    if not char:
        session.close()
        return "Character not found", 404

    # 1) Delete children in link tables first
    session.query(CharacterTitan).filter_by(character_id=char_id).delete(synchronize_session=False)
    session.query(CharacterOrganization).filter_by(character_id=char_id).delete(synchronize_session=False)
    session.query(EpisodeAppearance).filter_by(character_id=char_id).delete(synchronize_session=False)

    # 2) Now it's safe to delete the character itself
    session.delete(char)
    session.commit()
    session.close()

    return redirect(url_for("list_characters"))

# ---------- LLM QA route ----------

@app.route("/ask", methods=["GET", "POST"])
def ask_llm():
    sql = None
    rows = None
    columns = None
    error = None

    if request.method == "POST":
        question = request.form["question"]

        try:
            sql = question_to_sql(question)

            with engine.connect() as conn:
                result = conn.execute(text(sql))
                # convert Row objects -> dicts
                rows = [dict(r._mapping) for r in result]

                if rows:
                    columns = list(rows[0].keys())

        except Exception as e:
            error = str(e)

    return render_template("ask.html", sql=sql, rows=rows, columns=columns, error=error)




if __name__ == "__main__":
    app.run(debug=True)
