from sqlalchemy import (
    create_engine, Column, Integer, String, Text, Date,
    ForeignKey, Enum, UniqueConstraint, Index
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

# Use your MySQL user & password here
DATABASE_URL = "mysql+pymysql://Landry:Muntasir1@localhost/aot_fandom"

engine = create_engine(DATABASE_URL, echo=True)
SessionLocal = sessionmaker(bind=engine)

Base = declarative_base()


class Series(Base):
    __tablename__ = "series"

    series_id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String(100), nullable=False)
    description = Column(Text)
    start_year = Column(Integer)
    end_year = Column(Integer)

    seasons = relationship("Season", back_populates="series")


class Season(Base):
    __tablename__ = "season"
    __table_args__ = (
        UniqueConstraint("series_id", "season_number", name="uq_series_season"),
    )

    season_id = Column(Integer, primary_key=True, autoincrement=True)
    series_id = Column(Integer, ForeignKey("series.series_id"), nullable=False)
    season_number = Column(Integer, nullable=False)
    title = Column(String(100))
    summary = Column(Text)

    series = relationship("Series", back_populates="seasons")
    episodes = relationship("Episode", back_populates="season")


class Episode(Base):
    __tablename__ = "episode"
    __table_args__ = (
        Index("idx_episode_season", "season_id", "episode_number"),
    )

    episode_id = Column(Integer, primary_key=True, autoincrement=True)
    season_id = Column(Integer, ForeignKey("season.season_id"), nullable=False)
    episode_number = Column(Integer, nullable=False)
    title = Column(String(150), nullable=False)
    air_date = Column(Date)
    synopsis = Column(Text)

    season = relationship("Season", back_populates="episodes")
    appearances = relationship("EpisodeAppearance", back_populates="episode")


class Species(Base):
    __tablename__ = "species"

    species_id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text)

    characters = relationship("Character", back_populates="species")


class Character(Base):
    __tablename__ = "character"

    character_id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, unique=True)
    alias = Column(String(100))
    species_id = Column(Integer, ForeignKey("species.species_id"))
    birthdate = Column(Date)
    status = Column(
        Enum("alive", "dead", "unknown", name="status_enum"),
        nullable=False,
        default="unknown"
    )
    description = Column(Text)

    species = relationship("Species", back_populates="characters")
    organizations = relationship("CharacterOrganization", back_populates="character")
    titans = relationship("CharacterTitan", back_populates="character")
    appearances = relationship("EpisodeAppearance", back_populates="character")


class Organization(Base):
    __tablename__ = "organization"

    organization_id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, unique=True)
    type = Column(String(50))
    description = Column(Text)

    members = relationship("CharacterOrganization", back_populates="organization")


class CharacterOrganization(Base):
    __tablename__ = "character_organization"
    __table_args__ = (
        UniqueConstraint("character_id", "organization_id", name="pk_char_org"),
    )

    character_id = Column(Integer, ForeignKey("character.character_id"), primary_key=True)
    organization_id = Column(Integer, ForeignKey("organization.organization_id"), primary_key=True)
    role = Column(String(100))
    join_episode_id = Column(Integer, ForeignKey("episode.episode_id"), nullable=True)

    character = relationship("Character", back_populates="organizations")
    organization = relationship("Organization", back_populates="members")


class TitanType(Base):
    __tablename__ = "titan_type"

    titan_type_id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(Text)

    characters = relationship("CharacterTitan", back_populates="titan")


class CharacterTitan(Base):
    __tablename__ = "character_titan"
    __table_args__ = (
        UniqueConstraint("character_id", "titan_type_id", name="pk_character_titan"),
    )

    character_id = Column(Integer, ForeignKey("character.character_id"), primary_key=True)
    titan_type_id = Column(Integer, ForeignKey("titan_type.titan_type_id"), primary_key=True)
    first_appearance_episode_id = Column(Integer, ForeignKey("episode.episode_id"))

    character = relationship("Character", back_populates="titans")
    titan = relationship("TitanType", back_populates="characters")


class EpisodeAppearance(Base):
    __tablename__ = "episode_appearance"
    __table_args__ = (
        UniqueConstraint("episode_id", "character_id", name="pk_episode_character"),
    )

    episode_id = Column(Integer, ForeignKey("episode.episode_id"), primary_key=True)
    character_id = Column(Integer, ForeignKey("character.character_id"), primary_key=True)
    screen_time_minutes = Column(Integer)

    episode = relationship("Episode", back_populates="appearances")
    character = relationship("Character", back_populates="appearances")
